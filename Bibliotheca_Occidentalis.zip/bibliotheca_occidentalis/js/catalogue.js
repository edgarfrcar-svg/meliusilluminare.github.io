/* Bibliotheca Occidentalis — catalogue data */
window.BO = window.BO || {};

BO.sections = [
  {
    id: "science",
    name: "Science & Mathematics",
    blurb: "Number, nature, and the ordered cosmos — from Euclid to the moderns who still measured under heaven."
  },
  {
    id: "history",
    name: "History",
    blurb: "Chronicles, peoples, and the memory of Christendom and the nations."
  },
  {
    id: "philosophy",
    name: "Philosophy",
    blurb: "Being, knowing, and the good — pagan masters and the schools that baptized them."
  },
  {
    id: "theology",
    name: "Theology",
    blurb: "Sacred doctrine: Fathers, scholastics, mystics, and the teaching Church in print."
  },
  {
    id: "literature",
    name: "Literature",
    blurb: "Epic, lyric, drama, and the imaginative glory of the Christian West."
  }
];

/* Keep shelves alias for older links */
BO.shelves = BO.sections;

BO.rooms = [
  { id: "scriptorium", name: "The Scriptorium", blurb: "Where texts are copied, corrected, and loved into permanence.", essay: "A scriptorium is not a factory. It is a room where attention becomes ink. In the Christian West the copying of books was never mere information transfer; it was a work of mercy toward the next generation and an act of worship toward the Word who speaks in letters of human making." },
  { id: "cloister", name: "The Cloister", blurb: "Monastic wisdom — silence, lectio, and the long obedience.", essay: "The cloister taught Europe how to read slowly. Lectio divina, the Rule, the conferences of the desert — these books do not hurry the soul." },
  { id: "aula", name: "The Aula", blurb: "The lecture hall of the schools — disputations and clarity.", essay: "In the aula the question is king. Scholastic method is charity toward the confused. Distinctions are made so that truth may be held without injury." },
  { id: "nave", name: "The Nave", blurb: "Books that belong near the altar — rite, beauty, and sacrifice.", essay: "Some books are meant to be held standing. Missals, mystagogy, and the poetry of the liturgy train the imagination to see what the rite enacts." }
];

BO.centuryLabel = function (c) {
  if (c == null || c === "") return "—";
  var n = parseInt(c, 10);
  if (isNaN(n)) return String(c);
  if (n < 0) return Math.abs(n) + "th c. BC";
  var j = n % 10, k = n % 100;
  var suf = (j === 1 && k !== 11) ? "st" : (j === 2 && k !== 12) ? "nd" : (j === 3 && k !== 13) ? "rd" : "th";
  return n + suf + " century";
};

BO.authors = [
  { id: "augustine", name: "St. Augustine of Hippo", dates: "354–430", section: "theology", century: 5, blurb: "Doctor of Grace. The restless heart’s own biographer.", essay: "Aurelius Augustinus remains the most intimate of the Fathers and the most public. The Confessions invent a form: prayer as autobiography. The City of God teaches the West to distinguish the two loves that build two cities. To stock Augustine is to keep the grammar of conversion in print." },
  { id: "aquinas", name: "St. Thomas Aquinas", dates: "1225–1274", section: "theology", century: 13, blurb: "The Common Doctor. Clarity as a form of charity.", essay: "Thomas ordered the Catholic mind. The Summa remains a cathedral of questions. Against the Gentiles speaks outward without contempt. A serious Western library without Thomas is a house without its central beam." },
  { id: "dante", name: "Dante Alighieri", dates: "1265–1321", section: "literature", century: 14, blurb: "The poet of the Comedy — Hell, Purgatory, and the rose of Paradise.", essay: "Dante baptized epic. The Comedy is doctrine set on fire: justice, penance, and the vision of God in terza rima. Every Western bookshelf that claims seriousness eventually makes room for him." },
  { id: "anselm", name: "St. Anselm of Canterbury", dates: "1033–1109", section: "theology", century: 11, blurb: "Faith seeking understanding — and the logic of satisfaction.", essay: "The Proslogion still startles. Cur Deus Homo reframed the atonement for a millennium. He writes as a monk who believes reason is a friend of prayer." },
  { id: "newman", name: "St. John Henry Newman", dates: "1801–1890", section: "theology", century: 19, blurb: "Development of doctrine and the educated conscience.", essay: "Newman is the modern Father of the English tongue. The Essay on Development taught Catholics to think historically without becoming historicists. The Apologia remains a classic of intellectual honesty." },
  { id: "euclid", name: "Euclid", dates: "c. 300 BC", section: "science", century: -3, blurb: "The Elements — geometry as lasting form.", essay: "Euclid’s Elements trained the Western mind in demonstration. From the medieval quadrivium to Newton’s desk, the book taught that clarity can be cumulative." },
  { id: "aristotle", name: "Aristotle", dates: "384–322 BC", section: "philosophy", century: -4, blurb: "The Philosopher — ethics, metaphysics, nature.", essay: "Aristotle remains the pagan teacher the scholastics could not leave. The Ethics, the Metaphysics, and the natural works are the spine Thomas baptized." },
  { id: "plato", name: "Plato", dates: "c. 428–348 BC", section: "philosophy", century: -4, blurb: "The Academy’s founder — dialogue, form, and the city.", essay: "The Republic and the dialogues keep the West in argument with the cave and the sun. The Fathers argued with Plato because they could not ignore him." }
];

BO.books = [
  { id: "confessions", title: "Confessions", authorId: "augustine", author: "St. Augustine", section: "theology", century: 5, price: "$28", spine: "#5c3d2e", year: "c. 397–400", edition: "Hardcover · facing-page notes", blurb: "The restless heart told as prayer. Theology in the form of memory: the garden in Milan, Monica’s death, the two wills.\n\nEvery serious Christian library begins again with this book." },
  { id: "city-of-god", title: "The City of God", authorId: "augustine", author: "St. Augustine", section: "theology", century: 5, price: "$42", spine: "#3d4a5c", year: "413–426", edition: "Complete · 2 vols. cloth", blurb: "The two cities — self-love and the love of God — ordered through Roman crisis and biblical history.\n\nFoundation of Christian political thought." },
  { id: "summa-theo", title: "Summa Theologiae (Selections)", authorId: "aquinas", author: "St. Thomas Aquinas", section: "theology", century: 13, price: "$36", spine: "#4a3c6b", year: "1265–1274", edition: "Blackfriars text · study binding", blurb: "God, Trinity, creation, law, grace, and the virtues — questions for students who still believe a distinction can save a soul from confusion." },
  { id: "summa-contra", title: "Summa Contra Gentiles", authorId: "aquinas", author: "St. Thomas Aquinas", section: "theology", century: 13, price: "$34", spine: "#2e4a3c", year: "1259–1265", edition: "Complete · annotated", blurb: "Thomas speaking outward — natural reason as far as it will go, then the truths held by faith." },
  { id: "proslogion", title: "Proslogion & Major Works", authorId: "anselm", author: "St. Anselm", section: "theology", century: 11, price: "$24", spine: "#4a5c3d", year: "1077–1078", edition: "Seamless collection", blurb: "Proslogion, Cur Deus Homo, selected prayers. Faith seeking understanding." },
  { id: "apologia", title: "Apologia Pro Vita Sua", authorId: "newman", author: "St. John Henry Newman", section: "theology", century: 19, price: "$26", spine: "#5c4a2e", year: "1864", edition: "Critical text", blurb: "Newman’s defense of a life of intellectual conversion. English prose at full dignity." },
  { id: "development", title: "Essay on the Development of Christian Doctrine", authorId: "newman", author: "St. John Henry Newman", section: "theology", century: 19, price: "$27", spine: "#3d5c4a", year: "1845", edition: "Standard pagination", blurb: "How the Church can change without betraying herself." },
  { id: "rule-benedict", title: "The Rule of St. Benedict", authorId: null, author: "St. Benedict", section: "theology", century: 6, price: "$16", spine: "#3c4a3d", year: "c. 530", edition: "Pocket leatherette", blurb: "The little rule for beginners that organized the West’s monasteries." },
  { id: "imitation", title: "The Imitation of Christ", authorId: null, author: "Thomas à Kempis", section: "theology", century: 15, price: "$20", spine: "#5c3d4a", year: "c. 1418–1427", edition: "Gift binding", blurb: "Interior conversion without sentimentality — the great late-medieval devotional." },
  { id: "mystical-theology", title: "The Mystical Theology", authorId: null, author: "Pseudo-Dionysius", section: "theology", century: 6, price: "$18", spine: "#2e3d5c", year: "c. 500", edition: "Slim cloth", blurb: "Negative theology and the dazzling darkness — short, decisive, inexhaustible." },
  { id: "comedy", title: "The Divine Comedy", authorId: "dante", author: "Dante Alighieri", section: "literature", century: 14, price: "$45", spine: "#6b2e2e", year: "c. 1320", edition: "Verse translation · illustrated", blurb: "Inferno, Purgatorio, Paradiso — the pilgrim’s road from the dark wood to the rose." },
  { id: "beowulf", title: "Beowulf", authorId: null, author: "Anonymous", section: "literature", century: 8, price: "$22", spine: "#3d4a3c", year: "c. 700–1000", edition: "Facing-page verse", blurb: "The northern epic of hall, monster, and gift-throne — English poetry’s first great monument." },
  { id: "paradise-lost", title: "Paradise Lost", authorId: null, author: "John Milton", section: "literature", century: 17, price: "$24", spine: "#2e2e4a", year: "1667", edition: "Annotated epic", blurb: "The fall of the angels and of man in English blank verse — Protestant epic the Catholic reader still must know." },
  { id: "iliad", title: "The Iliad", authorId: null, author: "Homer", section: "literature", century: -8, price: "$28", spine: "#6b4a2e", year: "c. 8th c. BC", edition: "Verse translation", blurb: "Wrath, honor, and the death of heroes — the pagan epic the West never stopped rereading." },
  { id: "plato-republic", title: "The Republic", authorId: "plato", author: "Plato", section: "philosophy", century: -4, price: "$25", spine: "#3d4a6b", year: "c. 375 BC", edition: "Scholarly translation", blurb: "The cave, the city, the philosopher’s education." },
  { id: "aristotle-ethics", title: "Nicomachean Ethics", authorId: "aristotle", author: "Aristotle", section: "philosophy", century: -4, price: "$24", spine: "#4a3d2e", year: "c. 350 BC", edition: "With scholastic notes", blurb: "Virtue, friendship, contemplation — the spine Thomas baptized." },
  { id: "aristotle-meta", title: "Metaphysics", authorId: "aristotle", author: "Aristotle", section: "philosophy", century: -4, price: "$26", spine: "#2e3d4a", year: "c. 350 BC", edition: "Standard translation", blurb: "Being as being — the book that named a science for the schools." },
  { id: "boethius", title: "The Consolation of Philosophy", authorId: null, author: "Boethius", section: "philosophy", century: 6, price: "$20", spine: "#4a5c6b", year: "c. 524", edition: "Prose & verse", blurb: "Lady Philosophy in the prison cell — the bridge-book of late antiquity." },
  { id: "descartes-med", title: "Meditations on First Philosophy", authorId: null, author: "René Descartes", section: "philosophy", century: 17, price: "$18", spine: "#5c5c6b", year: "1641", edition: "Study text", blurb: "The cogito and the modern turn — stocked so the tradition can answer it." },
  { id: "eusebius", title: "Ecclesiastical History", authorId: null, author: "Eusebius of Caesarea", section: "history", century: 4, price: "$30", spine: "#5c4a3d", year: "c. 325", edition: "Complete", blurb: "The first great Church history — martyrs, heresies, the peace of Constantine." },
  { id: "bede", title: "Ecclesiastical History of the English People", authorId: null, author: "St. Bede", section: "history", century: 8, price: "$28", spine: "#3d5c4a", year: "c. 731", edition: "Complete", blurb: "How the faith came to the English — chronology, kings, and missionaries." },
  { id: "gibbon", title: "The Decline and Fall of the Roman Empire (Abridged)", authorId: null, author: "Edward Gibbon", section: "history", century: 18, price: "$32", spine: "#4a3d2e", year: "1776–1789", edition: "Abridged scholarly", blurb: "The great Enlightenment narrative of Rome’s fall — to be read and argued with." },
  { id: "thucydides", title: "History of the Peloponnesian War", authorId: null, author: "Thucydides", section: "history", century: -5, price: "$27", spine: "#2e4a5c", year: "c. 400 BC", edition: "Complete", blurb: "War, rhetoric, and human nature under pressure — classical history at full severity." },
  { id: "euclid-elements", title: "The Elements", authorId: "euclid", author: "Euclid", section: "science", century: -3, price: "$30", spine: "#2e4a3d", year: "c. 300 BC", edition: "Illustrated books I–VI", blurb: "Definitions, postulates, propositions — the geometry that trained Europe’s mind." },
  { id: "ptolemy", title: "Almagest (Selections)", authorId: null, author: "Ptolemy", section: "science", century: 2, price: "$29", spine: "#3d3d5c", year: "c. 150", edition: "Selected books", blurb: "The classical cosmos of deferents and epicycles — the astronomy the Middle Ages inherited." },
  { id: "newton-principia", title: "Principia (Selected Readings)", authorId: null, author: "Isaac Newton", section: "science", century: 17, price: "$35", spine: "#1e2e4a", year: "1687", edition: "Guided excerpts", blurb: "Laws of motion and universal gravitation — the mathematical principles of natural philosophy." },
  { id: "galileo", title: "Dialogue Concerning the Two Chief World Systems", authorId: null, author: "Galileo Galilei", section: "science", century: 17, price: "$26", spine: "#4a2e2e", year: "1632", edition: "Complete translation", blurb: "Salviati, Sagredo, Simplicio — the argument that moved the earth." },
  { id: "pascal-pensees", title: "Pensées", authorId: null, author: "Blaise Pascal", section: "philosophy", century: 17, price: "$22", spine: "#5c2e4a", year: "1670", edition: "Ordered fragments", blurb: "Mathematics, wager, and the heart’s reasons — science and theology in one fractured genius." },
  { id: "augustine-music", title: "De Musica (Selections)", authorId: "augustine", author: "St. Augustine", section: "science", century: 5, price: "$19", spine: "#4a3d5c", year: "c. 387–391", edition: "Selections", blurb: "Number, rhythm, and the liberal arts — Augustine on music as ordered measure." }
];

BO.getBook = function (id) {
  return BO.books.find(function (b) { return b.id === id; });
};
BO.getAuthor = function (id) {
  return BO.authors.find(function (a) { return a.id === id; });
};
BO.getSection = function (id) {
  return BO.sections.find(function (s) { return s.id === id; });
};
BO.getShelf = BO.getSection;
BO.getRoom = function (id) {
  return BO.rooms.find(function (r) { return r.id === id; });
};
BO.centuriesIn = function (sectionId) {
  var set = {};
  BO.books.forEach(function (b) {
    if (sectionId && sectionId !== "all" && b.section !== sectionId) return;
    if (b.century != null) set[b.century] = true;
  });
  return Object.keys(set).map(Number).sort(function (a, b) { return a - b; });
};
