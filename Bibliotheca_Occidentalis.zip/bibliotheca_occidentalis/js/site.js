(function () {
  function dust() {
    var layer = document.createElement("div");
    layer.className = "dust-layer";
    layer.setAttribute("aria-hidden", "true");
    document.body.appendChild(layer);
    for (var i = 0; i < 18; i++) {
      var d = document.createElement("span");
      d.className = "dust";
      d.style.left = Math.random() * 100 + "%";
      d.style.animationDuration = 12 + Math.random() * 18 + "s";
      d.style.animationDelay = Math.random() * 10 + "s";
      d.style.opacity = String(0.2 + Math.random() * 0.5);
      layer.appendChild(d);
    }
  }
  function nav() {
    var btn = document.querySelector(".nav-toggle");
    var nav = document.querySelector(".site-nav");
    if (!btn || !nav) return;
    btn.addEventListener("click", function () {
      nav.classList.toggle("open");
    });
  }
  document.addEventListener("DOMContentLoaded", function () {
    dust();
    nav();
  });
})();
